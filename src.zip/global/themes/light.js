const light = {
  title: "light",
  colors: {
    primary: "#FF657F",
    secondary: "#f9d423",
    background: "#EBE7E7",
    text: "#18192D",
    searchBoxBg: "#292929",
    textSearchBox: "#EBE7E7",
  },
};

export default light;
