const dark = {
  title: "dark",
  colors: {
    primary: "#FF657F",
    secondary: "#f9d423",
    background: "#18192D",
    text: "#EBE7E7",
    searchBoxBg: "#EBE7E7",
    textSearchBox: "#292929",
  },
};

export default dark;
